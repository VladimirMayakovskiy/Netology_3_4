﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Arkanoid
{
    public class CameraWASD : MonoBehaviour
    {
        public static CameraWASD Self;

        private float _speedSide;
        private float _mouseSensitivity;

        private Vector3 _mousePreveousePos;
        private float _rotationY;
        private float _rotationX;

        public delegate void EventsHandler(BallManager ball);
        public static event EventsHandler OnAddBall;

        private GameObject _ball;
        private Material _ballMaterial;

        public (Vector2 ResPosX, Vector2 ResPosY, Vector3 Pos, Vector2 ResRotX, Vector2 ResRotY) CameraPosition;

        private Coroutine _coroutine;
        public void CreateBall()
        {
            _ball = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            _ball.transform.localScale = Constants.Self.BallSize;
            _ball.transform.position = this.transform.position + transform.forward * 8 - transform.up * 6;
            _ball.transform.rotation = this.transform.rotation;
            _ball.transform.parent = this.transform;
            if (_ball.TryGetComponent(out MeshRenderer meshRenderer)) meshRenderer.material = _ballMaterial;
        }
        private void Awake() => Self = this;
        private void Start()
        {
             CameraPosition = Constants.Self.ListOfCameraPosition[0];
             _speedSide = Constants.Self.SpeedSide;

            _ballMaterial = Resources.Load("Arkanoid/BlackMat", typeof(Material)) as Material;
            CreateBall();

            if (PlayerPrefs.HasKey(Constants.Self.__mouseSensitivityPrefsString)) _mouseSensitivity = PlayerPrefs.GetFloat(Constants.Self.__mouseSensitivityPrefsString);
        }
        private void Update()
        {
            //Если текущий шар уничтожен (например, он не был пойман и попал в ворота), создает новый шар
            if (Input.GetKeyDown(KeyCode.Mouse0))
            {
                if (_ball.gameObject.GetComponent<BallManager>()) return;
                _ball.transform.parent = null;
                var r = _ball.AddComponent<BallManager>();
                OnAddBall?.Invoke(r);
            }

            //Открыть меню паузы
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (!UIManager.Self.IsPaused) UIManager.Self.Pause();
            }
            #region Rotation
            Vector3 _mouseDelta;
            if (Input.GetMouseButtonDown(1))
            {
                _mousePreveousePos = Input.mousePosition;
            }

            if (Input.GetMouseButton(1))
            {
                _mouseDelta = Input.mousePosition - _mousePreveousePos;
                _mousePreveousePos = Input.mousePosition;

                _rotationX -= _mouseDelta.y * _mouseSensitivity;
                _rotationY += _mouseDelta.x * _mouseSensitivity;

                transform.localEulerAngles = new Vector3(Mathf.Clamp(_rotationX, CameraPosition.ResRotX.x, CameraPosition.ResRotX.y),
                    Mathf.Clamp(_rotationY, CameraPosition.ResRotY.x, CameraPosition.ResRotY.y), 0);
            }
            #endregion

            #region Movement
            var _inputX = Input.GetAxis("Horizontal");
            var _inputY = Input.GetAxis("Vertical");

            if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D))
                transform.position += Vector3.right * _inputX * _speedSide * Time.deltaTime;
            if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.S))
                transform.position += Vector3.up * _inputY * _speedSide * Time.deltaTime;

            if (Input.GetKeyUp(KeyCode.A) || Input.GetKeyUp(KeyCode.D))
            {
                _coroutine = null;
                _coroutine = StartCoroutine(InertiaX(_inputX));
            }
            if (Input.GetKeyUp(KeyCode.W) || Input.GetKeyUp(KeyCode.S))
            {
                _coroutine = null;
                _coroutine = StartCoroutine(InertiaY(_inputY));
            }

            transform.position = new Vector3(Mathf.Clamp(transform.position.x, CameraPosition.ResPosX.x, CameraPosition.ResPosX.y),
                Mathf.Clamp(transform.position.y, CameraPosition.ResPosY.x, CameraPosition.ResPosY.y), transform.position.z);
            #endregion
        }

        /// <summary>
        /// Инерция по оси Х при передвижении 
        /// </summary>
        /// <param name="inputX"> Сила и направление нажатия </param>
        private IEnumerator InertiaX(float inputX)
        {
            float rangeTime = Constants.Self.DurationInertia;
            while (rangeTime >= 0)
            {
                rangeTime -= Time.deltaTime;
                transform.position += Vector3.right * _speedSide * rangeTime * inputX * Time.deltaTime;
                yield return new WaitForSeconds(0.002f);
            }
            yield return null;
        }
        /// <summary>
        /// Инерция по оси Y при передвижении 
        /// </summary>
        /// <param name="inputY"> Сила и направление нажатия </param>
        private IEnumerator InertiaY(float inputY)
        {
            float rangeTime = Constants.Self.DurationInertia;
            while (rangeTime >= 0)
            {
                rangeTime -= Time.deltaTime;
                transform.position += Vector3.up * _speedSide * rangeTime * inputY * Time.deltaTime;
                yield return new WaitForSeconds(0.002f);
            }
            yield return null;
        }
    }
}