﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace Arkanoid
{
    public class HealthBar : MonoBehaviour
    {
        [SerializeField, Tooltip("Жизни игрока")]
        private List<GameObject> _hps;
        private TextMeshProUGUI _text;
        private void Start()
        {
            _text = transform.GetComponentInChildren<TextMeshProUGUI>();
            if (_text == null) return;
            _text.text = $"{Constants.Self.Health}";
            foreach (var el in _hps) el.SetActive(true);
        }
        public void SetHp(int x)
        {
            if (x < 0 || x >= Constants.Self.Health || _hps.Count<x) return;
            _hps[x].SetActive(false);
            _text.text = $"{x}";
        }
    } 
}
