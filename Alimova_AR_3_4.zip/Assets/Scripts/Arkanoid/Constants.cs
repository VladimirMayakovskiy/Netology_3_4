﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Arkanoid
{
    public class Constants : MonoBehaviour
    {
        public static Constants Self;
        private void Awake() => Self = this;

        [Tooltip("Количество здоровья в начале уровня")]
        /// <summary>
        /// Количество здоровья в начале уровня
        /// </summary>
        public int Health = 3;

        [Tooltip("Скорость камеры")]
        /// <summary>
        /// Скорость камеры
        /// </summary>
        public float SpeedSide = 120f;
        [Tooltip("Скорость шара")]
        /// <summary>
        /// Скорость шара
        /// </summary>
        public float BallSpeedForward = 80f;
        [Tooltip("Ускорение шара")]
        /// <summary>
        /// Ускорение шара
        /// </summary>
        public float BallAcceleration = 1;
        [Tooltip("Длительность инерции (камера)")]
        /// <summary>
        /// Длительность инерции (камера)
        /// </summary>
        public float DurationInertia = 1.2f;

        /// <summary>
        /// Позиция, границы и ограничения поворота камеры 
        /// </summary>
        public List<(Vector2 ResPosX, Vector2 ResPosY, Vector3 Pos, Vector2 ResRotX, Vector2 ResRotY)> ListOfCameraPosition =
            new List<(Vector2 ResPosX, Vector2 ResPosY, Vector3 Pos, Vector2 ResRotX, Vector2 ResRotY)>
        {
            (new Vector2(-110, 110), new Vector2(-79, 79), new Vector3(0, 0, -225), new Vector2(-40, 40), new Vector2(-20, 20)),
            (new Vector2(-70, 60), new Vector2(266, 434), new Vector3(0, 350, -225), new Vector2(-40, 40), new Vector2(-40, 40)),
        };

        [Tooltip("Размер шара")]
        /// <summary>
        /// Размер шара
        /// </summary>
        public Vector3 BallSize = new Vector3(9, 9, 9);

        //Названия настроек чувствительности мыши и уровня сложности
        public string __mouseSensitivityPrefsString = "MouseSensitivity";
        public string _difficultyPrefsString = "Difficulty";
    }
}
