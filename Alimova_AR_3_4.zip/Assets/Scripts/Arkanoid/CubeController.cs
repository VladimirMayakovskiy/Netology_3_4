﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Arkanoid
{
    public class CubeController : MonoBehaviour
    {
        public delegate void EventsHandler(CubeController cube);
        public event EventsHandler OnCubeCollision;
        private void OnEnable() => transform.localEulerAngles = new Vector3(Random.Range(0, 360), Random.Range(0, 360), Random.Range(0, 360));
        private void OnCollisionEnter(Collision collision)
        {
            //При возникновении коллизии с шаром:
            if (collision.gameObject.GetComponent<BallManager>()) OnCubeCollision?.Invoke(this);
        }
    }
}