﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Arkanoid
{
    public class CameraARROWS : MonoBehaviour
    {
        public static CameraARROWS Self;

        private float _speedSide;
        private float _mouseSensitivity;

        private Vector3 _mousePreveousePos;
        private float _rotationY;
        private float _rotationX;

        public (Vector2 ResPosX, Vector2 ResPosY, Vector3 Pos, Vector2 ResRotX, Vector2 ResRotY) CameraPosition;

        private Coroutine _coroutine;
        private void Awake() => Self = this;
        private void Start()
        {
            CameraPosition = Constants.Self.ListOfCameraPosition[0];
            _speedSide = Constants.Self.SpeedSide;

            if (PlayerPrefs.HasKey(Constants.Self.__mouseSensitivityPrefsString)) _mouseSensitivity = PlayerPrefs.GetFloat(Constants.Self.__mouseSensitivityPrefsString);
        }
        private void Update()
        {
            #region Rotation
            Vector3 _mouseDelta;
            if (Input.GetMouseButtonDown(1))
            {
                _mousePreveousePos = Input.mousePosition;
            }

            if (Input.GetMouseButton(1))
            {
                _mouseDelta = Input.mousePosition - _mousePreveousePos;
                _mousePreveousePos = Input.mousePosition;

                _rotationX -= _mouseDelta.y * _mouseSensitivity;
                _rotationY += _mouseDelta.x * _mouseSensitivity;

                transform.localEulerAngles = new Vector3(Mathf.Clamp(_rotationX, CameraPosition.ResRotX.x, CameraPosition.ResRotX.y),
                    Mathf.Clamp(_rotationY, 180 + CameraPosition.ResRotY.x, 180 + CameraPosition.ResRotY.y), 0);
            }
            #endregion

            #region Movement
            var _inputX = Input.GetAxis("Horizontal") * (-1);
            var _inputY = Input.GetAxis("Vertical");

            if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow))
                transform.position += Vector3.right * _inputX * _speedSide * Time.deltaTime;
            if (Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.DownArrow))
                transform.position += Vector3.up * _inputY * _speedSide * Time.deltaTime;

            if (Input.GetKeyUp(KeyCode.LeftArrow) || Input.GetKeyUp(KeyCode.RightArrow))
            {
                _coroutine = null;
                _coroutine = StartCoroutine(InertiaX(_inputX));
            }
            if (Input.GetKeyUp(KeyCode.UpArrow) || Input.GetKeyUp(KeyCode.DownArrow))
            {
                _coroutine = null;
                _coroutine = StartCoroutine(InertiaY(_inputY));
            }

            transform.position = new Vector3(Mathf.Clamp(transform.position.x, CameraPosition.ResPosX.x, CameraPosition.ResPosX.y),
                Mathf.Clamp(transform.position.y, CameraPosition.ResPosY.x, CameraPosition.ResPosY.y), transform.position.z);
            #endregion
        }


        /// <summary>
        /// Инерция по оси Х при передвижении 
        /// </summary>
        /// <param name="inputX"> Сила и направление нажатия </param>
        private IEnumerator InertiaX(float inputX)
        {
            float rangeTime = Constants.Self.DurationInertia;
            while (rangeTime >= 0)
            {
                rangeTime -= Time.deltaTime;
                transform.position += Vector3.right * _speedSide * rangeTime * inputX * Time.deltaTime;
                yield return new WaitForSeconds(0.002f);
            }
            yield return null;
        }
        /// <summary>
        /// Инерция по оси Y при передвижении 
        /// </summary>
        /// <param name="inputY"> Сила и направление нажатия </param>
        private IEnumerator InertiaY(float inputY)
        {
            float rangeTime = Constants.Self.DurationInertia;
            while (rangeTime >= 0)
            {
                rangeTime -= Time.deltaTime;
                transform.position += Vector3.up * _speedSide * rangeTime * inputY * Time.deltaTime;
                yield return new WaitForSeconds(0.002f);
            }
            yield return null;
        }

    }
}