﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace Arkanoid
{
    public class SettingsManager : MonoBehaviour
    {
        [SerializeField]
        private TMP_Dropdown _dropdownDifficulty;
        [SerializeField]
        private Scrollbar _scrollbarSensitivity;
        [SerializeField, Tooltip("Scrollbar Master Volume")]
        private Image _scrollbarImage;
        [SerializeField, Tooltip("Спрайт, на который меняется изображение громкости звука при его отключении")]
        private Sprite _scrollbarChangedSprite;
        /// <summary>
        /// Изначальный спрайт скроллбара громкости звука
        /// </summary>
        private Sprite _scrollbarDefSprite;
        [SerializeField, Tooltip("Тогл отключения звука")]
        private Toggle _toggle;

        /// <summary>
        /// Уровень сложности, который устанавливает игрок
        /// </summary>
        private Difficulty _difficultyLevel = Difficulty.Easy;
        /// <summary>
        /// Чувствительность мыши
        /// </summary>
        private float _mouseSensitivity = 0.5f;

        private string __mouseSensitivityPrefsString = "MouseSensitivity";
        private string _difficultyPrefsString = "Difficulty";
        private void Start() => _scrollbarDefSprite = _scrollbarImage.sprite;
        private void OnEnable()
        {
            _scrollbarSensitivity.value = PlayerPrefs.GetFloat(__mouseSensitivityPrefsString);
            _dropdownDifficulty.value = PlayerPrefs.GetInt(_difficultyPrefsString);
        }
        private void OnDisable()
        {            PlayerPrefs.SetFloat(__mouseSensitivityPrefsString, _mouseSensitivity);
            PlayerPrefs.SetInt(_difficultyPrefsString, (int)_difficultyLevel);
        }
        public void SetDifficulty()
        {
            _difficultyLevel = (Difficulty)_dropdownDifficulty.value;
        }
        public void SetMouseSensitivity()
        {
            _mouseSensitivity = _scrollbarSensitivity.value;
        }
        public void OnToggle()
        {
            var isOn = _toggle.isOn;
            _scrollbarImage.sprite = isOn ? _scrollbarDefSprite : _scrollbarChangedSprite;
            _scrollbarImage.gameObject.GetComponent<Scrollbar>().interactable = isOn ? true : false;
        }
    }
    public enum Difficulty : byte
    {
        Easy = 0,
        Normal,
        Hard,
    }
}
