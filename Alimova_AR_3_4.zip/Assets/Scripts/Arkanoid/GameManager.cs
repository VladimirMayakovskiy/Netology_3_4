﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Arkanoid
{
    public class GameManager : MonoBehaviour
    {
        private int _health;

        private int _level = 0;

        private BallManager _currentBall;

        [SerializeField, Tooltip("Разрушаемые блоки, расположенные в центре тоннеля")]
        private List<CubeController> _cubeControllers = new List<CubeController>();
        [SerializeField, Tooltip("Количество неактивных/разрушенных блоков")]
        private int _countInactiveCubes = 0;

        [SerializeField, Tooltip("Панель здоровья первой камеры")]
        private HealthBar _healthBarCameraWASD;
        [SerializeField, Tooltip("Панель здоровья второй камеры")]
        private HealthBar _healthBarCameraARROWS;

        /// <summary>
        /// Делает неактивным куб, в который только что попал шар
        /// </summary>
        private void MakeCubeInactive(CubeController cube)
        {
            if (cube != null)
            {
                cube.gameObject.SetActive(false);
                _countInactiveCubes++;
            }
            if (_countInactiveCubes == _cubeControllers.Count)
            {
                if (_level >= 1)
                {
                    Debug.Log("WIN!");
                    Time.timeScale = 0;
                    Destroy(CameraWASD.Self);
                    Destroy(CameraARROWS.Self);
                }
                _level++;
                _level %= 2;

                CameraWASD.Self.CameraPosition = Constants.Self.ListOfCameraPosition[_level];
                CameraWASD.Self.gameObject.transform.position = Constants.Self.ListOfCameraPosition[_level].Pos;

                CameraARROWS.Self.CameraPosition = Constants.Self.ListOfCameraPosition[_level];
                CameraARROWS.Self.gameObject.transform.position = Constants.Self.ListOfCameraPosition[_level].Pos + Vector3.forward * 450;

                _cubeControllers[0].gameObject.transform.parent.position += Vector3.up * 350;
                _countInactiveCubes++;
                SetHp(1);
                MakeCubeActive();
            }
        }
        /// <summary>
        /// (При переходе на новый уровень) Восстанавливает разрушенные блоки, прибавляет максимум здоровья
        /// </summary>
        private void MakeCubeActive()
        {
            foreach (var el in _cubeControllers)
                el.gameObject.SetActive(true);
            _countInactiveCubes = 0;
            _health = Constants.Self.Health;
        }

        /// <summary>
        /// Добавляет текущий шар в поле зрения GameManger
        /// </summary>
        /// <param name="ball"> Текущий шар </param>
        private void OnAddBall(BallManager ball)
        {
            if (!ball) return;
            _currentBall = ball;
            _currentBall.OnSubtractLives += SetHp;
        }
        private void SetHp(int damage)
        {
            if (_countInactiveCubes == _cubeControllers.Count) MakeCubeInactive(null);

            _health += damage;
            if (_countInactiveCubes < _cubeControllers.Count)
            {
                _healthBarCameraARROWS.SetHp(_health);
                _healthBarCameraWASD.SetHp(_health);
            }
            if (_currentBall != null) Destroy(_currentBall.gameObject);
            _currentBall = null;
            CameraWASD.Self.CreateBall();
            if (_health <= 0)
            {
                Debug.Log("GAMEOVER");
                Time.timeScale = 0f;
                Destroy(CameraWASD.Self);
                Destroy(CameraARROWS.Self);
            }
        }
        private void Start()
        {
            _health = Constants.Self.Health;
            CameraWASD.Self.CameraPosition = Constants.Self.ListOfCameraPosition[_level];
            CameraWASD.Self.gameObject.transform.position = Constants.Self.ListOfCameraPosition[_level].Pos;
            CameraARROWS.Self.CameraPosition = Constants.Self.ListOfCameraPosition[_level];
            CameraARROWS.Self.gameObject.transform.position = Constants.Self.ListOfCameraPosition[_level].Pos + Vector3.forward * 450;
        }
        private void OnEnable()
        {
            CameraWASD.OnAddBall += OnAddBall;
            foreach (var el in _cubeControllers) el.OnCubeCollision += MakeCubeInactive;
        }
        private void OnDisable()
        {
            CameraWASD.OnAddBall -= OnAddBall;
            foreach (var el in _cubeControllers) el.OnCubeCollision -= MakeCubeInactive;
            if (_currentBall) _currentBall.OnSubtractLives -= SetHp;
        }
    }
}