﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Arkanoid
{
    public class UIManager : MonoBehaviour
    {
        public static UIManager Self;

        public bool IsPaused { get; private set; }
        [SerializeField, Tooltip("Обязательна для Игровой сцены")]
        private GameObject _pausePanel;

        private bool _isSettingsOpened = false;
        [Space, SerializeField, Tooltip("Обязательна для Меню сцены")]
        private GameObject _settingsPanel;
        [SerializeField, Tooltip("Обязательна для Меню сцены")]
        private GameObject _menuPanel;
        private void Awake() => Self = this;
        private void Start() => UnPause();

        /// <param name="x">Номер сцены, которую нужно загрузить</param>
        public void LoadScene(int x) => SceneManager.LoadScene(x);
        /// <summary>
        /// Открывает или закрывает панель настроек
        /// </summary>
        public void OpenAndCloseSettings()
        {
            if (_menuPanel == null || _settingsPanel == null) return;
            if (!_isSettingsOpened)
            {
                _settingsPanel.SetActive(true);
                _menuPanel.SetActive(false);
                _isSettingsOpened = true;
            }
            else
            {
                _settingsPanel.SetActive(false);
                _menuPanel.SetActive(true);
                _isSettingsOpened = false;
            }
        }
        /// <summary>
        /// Ставит игру на паузу (Игровая сцена)
        /// </summary>
        public void Pause()
        {
            if (CameraWASD.Self == null || CameraARROWS.Self == null) return;
            CameraWASD.Self.enabled = false;
            CameraARROWS.Self.enabled = false;

            Time.timeScale = 0f;
            _pausePanel.SetActive(true);
            IsPaused = true;
        }
        public void UnPause()
        {
            if (CameraWASD.Self == null || CameraARROWS.Self == null) return;
            CameraWASD.Self.enabled = true;
            CameraARROWS.Self.enabled = true;

            Time.timeScale = 1f;
            _pausePanel.SetActive(false);
            IsPaused = false;
        }
        /// <summary>
        /// Выход из игры
        /// </summary>
        public void Exit()
        {
            Time.timeScale = 0f;
            Application.Quit();
        }
    }
}
