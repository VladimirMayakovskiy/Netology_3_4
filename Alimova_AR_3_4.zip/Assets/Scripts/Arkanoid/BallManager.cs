﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Arkanoid
{
    [RequireComponent(typeof(Rigidbody), typeof(Collider))]
    public class BallManager : MonoBehaviour
    {
        private Rigidbody _rb;

        private float _speedForward;
        public float _acceleration;

        public delegate void EventsHandler(int x);
        public event EventsHandler OnSubtractLives;
        private void Start()
        {
            _speedForward = Constants.Self.BallSpeedForward;
            _acceleration = Constants.Self.BallAcceleration;
            _rb = GetComponent<Rigidbody>();
            _rb.useGravity = false;
            _rb.constraints = RigidbodyConstraints.FreezeRotation;
            _rb.velocity = _speedForward * transform.forward;
        }
        private void OnCollisionEnter(Collision collision)
        {
            //Отражение от объектов
            Vector3 target = Vector3.Reflect(transform.forward, collision.GetContact(0).normal);
            transform.rotation = Quaternion.LookRotation(target);
            _rb.velocity = target.normalized * _speedForward * _acceleration;
            if (collision.gameObject.GetComponent<CubeController>()) _acceleration += 0.1f;

            //Столкновение с воротами
            if (!collision.gameObject.GetComponent<GuardController>()) return;
            OnSubtractLives?.Invoke(-1);
        }
    }
}